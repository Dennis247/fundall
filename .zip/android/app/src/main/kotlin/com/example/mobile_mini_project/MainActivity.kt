package com.example.mobile_mini_project

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
