import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:mobile_mini_project/ui/widgets/backgroundWidget.dart';
import 'package:mobile_mini_project/utils/appStyles.dart';
import 'package:mobile_mini_project/utils/constants.dart';
import 'package:sliding_sheet/sliding_sheet.dart';

class WelcomeHomePage extends StatelessWidget {
  static final String routeName = "welcome-homePage";

  _buildAmountWidget(
      {String title, String amount, String daysCount, Size size}) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Text(title, style: AppStyles.labelTextStyle),
        SizedBox(
          height: size.height * 0.01,
        ),
        Text(amount, style: AppStyles.mediumW2hiteTextStyle),
        SizedBox(
          height: size.height * 0.01,
        ),
        Text(daysCount, style: AppStyles.verySmallTextStyle)
      ],
    );
  }

  _buildCardTypeWidget({String image, String description, Size screenSize}) {
    return Row(
      children: <Widget>[
        Container(
          height: 45,
          width: 45,
          decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.white,
              image: DecorationImage(
                image: AssetImage(image),
              )),
        ),
        SizedBox(
          width: screenSize.width * 0.05,
        ),
        Text(description, style: AppStyles.whitelabelTextStyle)
      ],
    );
  }

  _buildStackLayOut(Size screenSize) {
    return Stack(
      children: <Widget>[
        BackgroundWidget(),
        SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: <Widget>[
                    Icon(
                      FontAwesomeIcons.signOutAlt,
                      color: Colors.white,
                    ),
                    Text("Fundall e-Wallet",
                        style: AppStyles.appLargeWhiteTextSTyle),
                    CircleAvatar(
                      radius: 25,
                    )
                  ],
                ),
                SizedBox(
                  height: screenSize.height * 0.05,
                ),
                RichText(
                    text: TextSpan(children: [
                  TextSpan(
                      text: "Account ID: ",
                      style: AppStyles.smallWhiteTextStyle),
                  TextSpan(
                      text: "901672789, Providus",
                      style: AppStyles.labelTextStyle),
                ])),
                SizedBox(
                  height: screenSize.height * 0.05,
                ),
                Text("Total Balance", style: AppStyles.mediumWhiteTextStyle),
                SizedBox(
                  height: screenSize.height * 0.02,
                ),
                Text("₦12,634.37", style: AppStyles.largeNumericTextSTyle),
                SizedBox(
                  height: screenSize.height * 0.05,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: <Widget>[
                    _buildAmountWidget(
                        title: "Income",
                        amount: "₦12,634.37",
                        daysCount: "* last 30 days",
                        size: screenSize),
                    _buildAmountWidget(
                        title: "Spent",
                        amount: "₦12,634.37",
                        daysCount: "",
                        size: screenSize),
                  ],
                ),
                SizedBox(
                  height: screenSize.height * 0.08,
                ),
                Container(
                  width: screenSize.width * 0.7,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisSize: MainAxisSize.max,
                    children: <Widget>[
                      _buildCardTypeWidget(
                          screenSize: screenSize,
                          image: "assets/images/diamond.png",
                          description: "Add other cards"),
                      SizedBox(
                        height: screenSize.height * 0.03,
                      ),
                      _buildCardTypeWidget(
                          screenSize: screenSize,
                          image: "assets/images/glasscup.png",
                          description: "Request for new Lifestyle Card"),
                      SizedBox(
                        height: screenSize.height * 0.03,
                      ),
                      _buildCardTypeWidget(
                          screenSize: screenSize,
                          image: "assets/images/plane.png",
                          description: "Manage Card Settings"),
                    ],
                  ),
                )
              ],
            ),
          ),
        )
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final screenSize = Constants.getScreenSize(context);
    return SafeArea(
      child: Scaffold(
        body: SlidingSheet(
          elevation: 8,
          cornerRadius: 50,
          snapSpec: const SnapSpec(
            // Enable snapping. This is true by default.
            snap: true,
            // Set custom snapping points.
            snappings: [0.4, 1.0],
            // Define to what the snappings relate to. In this case,
            // the total available space that the sheet can expand to.
            positioning: SnapPositioning.relativeToAvailableSpace,
          ),
          // The body widget will be displayed under the SlidingSheet
          // and a parallax effect can be applied to it.
          body: Center(
            child: _buildStackLayOut(screenSize),
          ),
          builder: (context, state) {
            // This is the content of the sheet that will get
            // scrolled, if the content is bigger than the available
            // height of the sheet.
            return Container(
              height: screenSize.height * 0.85,
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        Text("Cards",
                            style: TextStyle(
                              fontFamily: 'FoundersGrotesk',
                              color: Color(0xff000000),
                              fontSize: 27,
                              fontWeight: FontWeight.w500,
                              fontStyle: FontStyle.normal,
                            )),
                        Row(
                          children: <Widget>[
                            Icon(FontAwesomeIcons.solidCircle),
                            SizedBox(width: screenSize.width * 0.03),
                            Icon(FontAwesomeIcons.solidCircle)
                          ],
                        )
                      ],
                    ),
                    Container(
                        child: new Text("Fundall Lifestyle Card",
                            style: TextStyle(
                              fontFamily: 'FoundersGrotesk',
                              color: Color(0xff000000),
                              fontSize: 9,
                              fontWeight: FontWeight.w500,
                              fontStyle: FontStyle.normal,
                            )),
                        width: screenSize.width * 0.45,
                        height: screenSize.height * 0.35,
                        decoration: new BoxDecoration(
                            color: Color(0xffc4c4c4),
                            borderRadius: BorderRadius.circular(10))),
                    Text("Today",
                        style: TextStyle(
                          fontFamily: 'FoundersGrotesk',
                          color: Color(0xff000000),
                          fontSize: 27,
                          fontWeight: FontWeight.w500,
                          fontStyle: FontStyle.normal,
                        ))
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
