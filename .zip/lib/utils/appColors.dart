import 'package:flutter/material.dart';

class AppColors {
  static final Color greenColor = Color(0xff4ce895);
  static final Color greyColor = Colors.grey[400];
}
